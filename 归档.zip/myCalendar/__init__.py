from myCalendar.PresentDate import PresentDate
from myCalendar.doc import *