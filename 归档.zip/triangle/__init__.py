from triangle.triangle import is_right, type_of_triangle, decide_triangle_type, description
from triangle.doc import md1, md2, md3