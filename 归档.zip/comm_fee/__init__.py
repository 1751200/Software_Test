from comm_fee.q3 import calculate_comm_fee
from comm_fee.doc import *