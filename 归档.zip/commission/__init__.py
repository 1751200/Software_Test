from commission.q3 import calculate_computer_commission
from commission.doc import *